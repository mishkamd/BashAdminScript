#!/bin/bash

while true; do
echo "____________________________________________"
echo "| Bine ați venit în SuperAdmin Management! |"
echo "| Vă rugăm să alegeți o opțiune:           |"
echo "| 1.  Settings Linux                       |"
echo "| 2.  Configurare SSH                      |"
echo "| 3.  Adăugare Localadmin                  |"
echo "| 4.  Adăugare server în AD                |"
echo "| 5.  Hardering de securitate              |"
echo "| 6.  NTP si localizare                    |"
echo "| 7.  Configurare Proxy                    |"
echo "| 8.  Șterge Pachete și actualizează       |"
echo "| 9.  Resize ROOT Disk                     |"
echo "| 10. Configurare Mail                     |"
echo "| 11. User manager                         |"
echo "| 0.  Inchide Scriptul                     |"
echo "--------------------------------------------"
read -p "Introduceți numărul opțiunii: " nr

case $nr in
        0)
            echo "Ieșire din Script."
            exit 0
            ;;
        1)
            clear
            . ./core/001_set_linux.sh
            ;;
        2)
            clear
            . ./core/002_ssh_reconfig.sh
            ;;
        3)
            clear
            . ./core/003_localadmin.sh
            ;;
        4)
            clear
            . ./core/004_join_to_ad.sh
            ;;
        5)
            clear
            . ./core/005_hardening.sh
            ;;
        6)
            clear
            . ./core/006_timesync.sh
            ;;
        7)
            clear
            . ./core/007_proxy_config.sh
            ;;
        8)
            clear
            . ./core/008_clear_linux.sh
            ;;
        9)
            clear
            . ./core/009_resize_disk.sh
            ;;
	10)
            clear
            . ./core/010_mail_config.sh
            ;;
	11)
            clear
            . ./core/011_user_manager.sh
            ;;
        *)
        echo "Opțiune invalidă."
            ;;
    esac
done
