#!/bin/bash

# Verifică dacă rulezi ca root
if [ "$EUID" -ne 0 ]; then
    echo "Acest script trebuie rulat ca root. Folosește sudo."
    exit 1
fi

# Afișează discurile disponibile
echo "Discurile disponibile pe sistem:"
lsblk -d -o NAME,SIZE | grep -v "NAME"
echo

# Cere utilizatorului să aleagă un disc
read -p "Introdu numele discului pe care vrei să lucrezi (ex. sda): " disk
if [ ! -b "/dev/$disk" ]; then
    echo "Eroare: Discul /dev/$disk nu există!"
    exit 1
fi

# Afișează dimensiunea totală a discului
disk_size=$(lsblk -b -d --noheadings -o SIZE /dev/$disk)
if [ -z "$disk_size" ] || [ "$disk_size" -eq 0 ]; then
    echo "Eroare: Nu pot determina dimensiunea discului /dev/$disk!"
    exit 1
fi
disk_size_gb=$((disk_size / 1024 / 1024 / 1024))
echo "Dimensiunea totală a discului /dev/$disk: ${disk_size_gb} GB"
echo

# Funcție pentru a verifica dimensiunea introdusă
check_size() {
    local size=$1
    local max=$2
    if ! [[ "$size" =~ ^[0-9]+$ ]] || [ "$size" -le 0 ] || [ "$size" -gt "$max" ]; then
        echo "Eroare: Introdu o valoare validă între 1 și $max GB!"
        return 1
    fi
    return 0
}

# Dezactivează swap-ul
echo "Dezactivez swap-ul..."
swapoff -a || {
    echo "Eroare: Nu pot dezactiva swap-ul!"
    exit 1
}

# Inițializează dimensiunea rămasă
remaining_size=$disk_size_gb

# Cere dimensiunea pentru /
echo "Configurează partiția root (/):"
read -p "Câte GB vrei să aloci pentru / (max $remaining_size GB)? " root_size
check_size "$root_size" "$remaining_size" || exit 1
remaining_size=$((remaining_size - root_size))

# Cere dimensiunea pentru swap
echo "Configurează partiția swap:"
read -p "Câte GB vrei să aloci pentru swap (max $remaining_size GB)? " swap_size
check_size "$swap_size" "$remaining_size" || exit 1
remaining_size=$((remaining_size - swap_size))

# Afișează rezumatul
echo -e "\nRezumatul configurației tale:"
echo "Discul: /dev/$disk"
echo "Partiția /: $root_size GB"
echo "Partiția swap: $swap_size GB"
echo "Spațiu nealocat rămas: $remaining_size GB"
read -p "Ești mulțumit cu această configurație? (da/nu): " confirm
if [ "$confirm" != "da" ]; then
    echo "Script anulat."
    exit 0
fi

# Avertisment despre discul în uz
echo "Avertisment: Discul este în uz. Modificările vor fi vizibile după reboot."

# Aplică modificările cu fdisk
echo "Șterg toate partițiile existente și aplic noile modificări pe /dev/$disk..."
{
    # Șterge toate partițiile existente folosind doar "d" și Enter
    echo "d"              # Șterge prima partiție disponibilă
    echo ""               # Confirmă implicit
    echo "d"              # Șterge următoarea partiție (dacă există)
    echo ""               # Confirmă implicit
    echo "d"              # Șterge următoarea partiție (dacă există)
    echo ""               # Confirmă implicit

    # Creează partiția root (/)
    echo "n"              # Nouă partiție
    echo "p"              # Primară
    echo "1"              # Numărul 1
    echo "2048"           # Sector de început fix
    echo "+${root_size}G" # Dimensiune root
    echo "a"              # Fă-o bootabilă
    echo "1"              #

    # Creează partiția swap folosind tot spațiul rămas
    if [ "$swap_size" -gt 0 ]; then
        echo "n"              # Nouă partiție
        echo "p"              # Primară
        echo "2"              # Numărul 2
        echo ""               # Sector de început implicit
        echo ""               # Folosește tot spațiul rămas
        echo "t"              # Schimbă tipul
        echo "2"              # Partiția 2
        echo "82"             # Tip swap
    fi

    echo "w"              # Scrie modificările
} | fdisk /dev/$disk || {
    echo "Eroare la aplicarea modificărilor cu fdisk!"
    exit 1
}

# Verifică modificările (vor apărea după reboot)
echo "Verific modificările (notă: vor fi vizibile după reboot)..."
fdisk -l /dev/$disk

# Configurează și activează swap-ul conform exemplului tău
if [ "$swap_size" -gt 0 ]; then
    echo "După ce fdisk a terminat, creăm swap-ul pe /dev/${disk}2..."
    mkswap /dev/${disk}2 || {
        echo "Eroare: Nu pot crea swap-ul pe /dev/${disk}2!"
        exit 1
    }

    # Extrage UUID-ul din output-ul mkswap
    uuid=$(mkswap /dev/${disk}2 | grep -o "UUID=[a-f0-9-]\+" | cut -d= -f2)
    if [ -z "$uuid" ]; then
        # Dacă nu reușește cu mkswap, folosește blkid ca fallback
        uuid=$(blkid -s UUID -o value /dev/${disk}2)
        if [ -z "$uuid" ]; then
            echo "Eroare: Nu pot extrage UUID-ul pentru swap!"
            exit 1
        fi
    fi
    echo "UUID-ul swap-ului este: $uuid"
    echo "Acest UUID trebuie utilizat în /etc/fstab pentru a funcționa după reboot."

    # Fă o copie de rezervă a /etc/fstab
    cp /etc/fstab /etc/fstab.bak-$(date +%Y%m%d-%H%M%S) || {
        echo "Eroare: Nu pot crea o copie de rezervă a /etc/fstab!"
        exit 1
    }
    echo "Copie de rezervă a /etc/fstab creată."

    # Actualizează UUID-ul în /etc/fstab
    if grep -q "swap" /etc/fstab; then
        echo "Găsesc și actualizez intrarea swap în /etc/fstab..."
        sed -i "/swap/s/UUID=[a-f0-9-]\+/UUID=$uuid/" /etc/fstab || {
            echo "Eroare: Nu pot actualiza /etc/fstab!"
            exit 1
        }
        echo "UUID-ul swap din /etc/fstab a fost înlocuit cu cel nou."
    else
        echo "Nu există intrare swap în /etc/fstab. Adaug una nouă..."
        echo "# swap was on /dev/${disk}2 after partitioning" >> /etc/fstab
        echo "UUID=$uuid none swap sw 0 0" >> /etc/fstab
        echo "Intrare nouă adăugată în /etc/fstab."
    fi

    # Activează swap-ul
    echo "Activăm swap-ul pe /dev/${disk}2..."
    swapon /dev/${disk}2 || {
        echo "Eroare: Nu pot activa swap-ul pe /dev/${disk}2!"
        exit 1
    }
    echo "Swap-ul a fost activat cu succes!"
fi

resize2fs /dev/sda1

echo -e "\nPartițiile au fost create și swap-ul configurat cu succes!"
echo "Repornește sistemul pentru a aplica complet modificările."
echo "Verifică /etc/fstab după reboot pentru a te asigura că swap-ul este configurat corect."

update-initramfs -u -k all
update-grub
reboot
