#!/bin/bash
#hostname=$(hostname)

## Sterge sudoers curent
rm /etc/sudoers

## Purge si install la sudo package
apt-get -y purge sudo
apt-get -y install sudo

## Verifica daca exista acest user
#if [[ $(grep -q "localadmin" /etc/passwd) ]]; then
#  exit
#fi

## Creaza acest user
sudo useradd -m localadmin

## Adauga alerta atunci cand se logheaza cu utilizatorul localadmin
echo 'echo `date` LOGIN `id` | mail root@energbank.com' >> /home/localadmin/.profile

## Verifica daca localadmin user exista in sudoers fisier
if [[ ! $(grep -q "%networkadmins,%localadmin" /etc/sudoers.d/enb_sudoers) ]]; then
  ## Adauga localadmin user in sudoers fisier
  echo "%networkadmins,%localadmin ALL=(ALL) NOPASSWD:ALL" >> /etc/sudoers.d/enb_sudoers
fi

## Genereaza parola
length=10
password=$(cat /dev/urandom | tr -dc 'A-Za-z0-9' | fold -w $length | head -n 1)

## Modifica parola al user localadmin
echo "localadmin:$password" |sudo chpasswd

## Arata parola noua
echo "Parola noua localadmin: $password"
