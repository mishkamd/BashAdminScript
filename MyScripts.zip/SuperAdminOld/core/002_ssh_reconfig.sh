#!/bin/bash
cat >/etc/issue.net <<EOF
*****************************************************************************
*                     ACCESUL NEAUTORIZAT ESTE INTERZIS                     *
*              UNAUTHORIZED ACCESS TO THIS DEVICE IS PROHIBITED!            *
* Conform LEGII Nr. 1069 din 22.06.2000 cu privire la informatica,          *
* Articolul 4, accesul neautorizat la acest sistem informational este       *
* interzis, iar incalcarea prevede raspundere administrativa, materiala     *
* sau penala, dupa caz, conform legislatiei in vigoare.                     *
*****************************************************************************
EOF

grep 'AllowGroups networkadmins localadmin' /etc/ssh/sshd_config >/dev/null 2>&1 || (
  echo '' >>/etc/ssh/sshd_config
  echo 'PermitRootLogin no' >>/etc/ssh/sshd_config
  echo 'Banner /etc/issue.net' >>/etc/ssh/sshd_config
  echo 'AllowGroups networkadmins localadmin' >>/etc/ssh/sshd_config
)

systemctl restart sshd

if grep 'localadmin' /etc/passwd >/dev/null 2>&1; then
    # Aici puteți adăuga acțiunile pe care doriți să le realizați dacă utilizatorul există.
    echo "Utilizatorul 'localadmin' există."
else
    # Aici puteți adăuga acțiunile pe care doriți să le realizați dacă utilizatorul nu există.
    echo "Utilizatorul 'localadmin' nu există."
fi

grep '/etc/sudoers.d' /etc/sudoers >/dev/null 2>&1 && 
(
  usermod root -L
  echo 'user root has been locked.'
)
