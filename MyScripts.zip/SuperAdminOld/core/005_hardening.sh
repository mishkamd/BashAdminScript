#!/bin/bash

# Script de hardening pentru Debian 12
# Asigură-te că rulezi cu privilegii de root

# Verifică dacă utilizatorul este root
if [ "$EUID" -ne 0 ]; then
    echo "Acest script trebuie rulat ca root. Folosește sudo."
    exit 1
fi

echo "Începerea procesului de hardening pentru Debian 12..."

# 1. Actualizarea Sistemului și Pachetelor de Securitate, inclusiv instalare pachete suplimentare
echo "Actualizare sistem..."
apt update && apt full-upgrade -y

echo "Instalare pachete suplimentare (mc, curl, wget)..."
for pkg in mc curl wget; do
    if dpkg -l | grep -q "^ii\s\+${pkg}\s"; then
        echo "Pachetul ${pkg} este deja instalat, sărim peste."
    else
        echo "Instalare pachet ${pkg}..."
        apt install -y ${pkg}
        if [ $? -eq 0 ]; then
            echo "Pachetul ${pkg} a fost instalat cu succes."
        else
            echo "Eroare la instalarea pachetului ${pkg}."
            exit 1
        fi
    fi
done

# echo "Instalare și configurare unattended-upgrades..."
# apt install unattended-upgrades -y
# dpkg-reconfigure --priority=low unattended-upgrades

# Configurare unattended-upgrades
# cat <<EOF > /etc/apt/apt.conf.d/50unattended-upgrades
# Unattended-Upgrade::Allowed-Origins {
    # "origin=Debian,codename=\${distro_codename},label=Debian-Security";
# };
# Unattended-Upgrade::Package-Blacklist {
    # "openssh-server";
    # "nginx";
# };
# Unattended-Upgrade::Automatic-Reboot "false";
# EOF

# Curățare APT
echo "Curățare cache APT și eliminare pachete inutile..."
apt autoremove -y
apt autoclean

# Eliminare Telnet
echo "Verificare și eliminare Telnet..."
if dpkg -l | grep -q telnet; then
    echo "Telnet este instalat. Îl eliminăm..."
    apt purge telnet -y
    echo "Telnet a fost eliminat."
else
    echo "Telnet nu este instalat."
fi

# 2. Dezactivarea Contului Root pentru SSH
echo "Dezactivare autentificare root prin SSH..."
echo "PermitRootLogin no" >> /etc/ssh/sshd_config
systemctl restart sshd

# 3. Implementarea Firewall-ului (UFW) - Doar IPv4
echo "Configurare UFW cu suport doar IPv4..."
apt install ufw -y

# Dezactivare IPv6 în UFW
sed -i 's/IPV6=yes/IPV6=no/' /etc/default/ufw

ufw default deny incoming
ufw default allow outgoing
ufw allow from 10.118.50.0/24 to any port 22  # Permite SSH doar din subrețeaua 10.118.50.0/24 (IPv4)
ufw allow from 10.118.10.161 to any port 6556  # Permite acces de la 10.118.10.161 pe portul 6556
ufw --force enable

# 4. Protecție Împotriva Atacurilor Brute-Force
echo "Instalare și configurare fail2ban..."
apt install fail2ban -y
cat <<EOF > /etc/fail2ban/jail.local
[sshd]
enabled = true
bantime = 1800  # 30 minute (1800 secunde)
findtime = 600
maxretry = 5
EOF
systemctl restart fail2ban

# 5. Protecție Kernel și sysctl, cu verificare pentru duplicări
echo "Configurare sysctl cu verificare pentru duplicări..."
SYSCTL_CONF="/etc/sysctl.conf"

# Funcție pentru a adăuga o setare doar dacă nu există
add_sysctl() {
    local key="$1"
    local value="$2"
    if ! grep -q "^\s*${key}\s*=\s*${value}\s*$" "$SYSCTL_CONF"; then
        echo "${key} = ${value}" >> "$SYSCTL_CONF"
        echo "Adăugat: ${key} = ${value}"
    else
        echo "Setarea ${key} = ${value} există deja, sărim peste."
    fi
}

# Adăugare setări de securitate IPv4 și dezactivare IPv6
echo "# Setări de securitate IPv4" >> "$SYSCTL_CONF"
add_sysctl "net.ipv4.conf.all.rp_filter" "1"
add_sysctl "net.ipv4.conf.default.rp_filter" "1"
add_sysctl "net.ipv4.conf.all.accept_redirects" "0"
add_sysctl "net.ipv4.conf.default.accept_redirects" "0"
add_sysctl "net.ipv4.conf.all.secure_redirects" "0"
add_sysctl "net.ipv4.conf.default.secure_redirects" "0"
add_sysctl "net.ipv4.icmp_echo_ignore_broadcasts" "1"
add_sysctl "net.ipv4.tcp_syncookies" "1"
add_sysctl "kernel.sysrq" "0"

echo "# Dezactivare IPv6" >> "$SYSCTL_CONF"
add_sysctl "net.ipv6.conf.all.disable_ipv6" "1"
add_sysctl "net.ipv6.conf.default.disable_ipv6" "1"
add_sysctl "net.ipv6.conf.lo.disable_ipv6" "1"

# Aplicare setări
sysctl -p

# 6. Instalare agent CheckMK
echo "Instalare agent CheckMK..."
CHECKMK_URL="http://10.118.10.161/enb/check_mk/agents/"

# Verificare accesibilitate server
echo "Verificare conectivitate la serverul CheckMK..."
if ping -c 3 10.118.10.161 >/dev/null 2>&1; then
    echo "Serverul 10.118.10.161 este accesibil."
else
    echo "Eroare: Serverul 10.118.10.161 nu răspunde la ping. Verifică rețeaua sau adresa."
    exit 1
fi

# Obținere dinamică a celui mai recent fișier .deb
echo "Determinarea celui mai recent fișier CheckMK .deb..."
CHECKMK_FILE=$(wget -qO- "${CHECKMK_URL}" | grep -o 'check-mk-agent_[0-9.]\+p[0-9]\+-[0-9]\+_all\.deb' | sort -V | tail -n 1)

if [ -z "$CHECKMK_FILE" ]; then
    echo "Eroare: Nu s-a găsit niciun fișier .deb valid pe ${CHECKMK_URL}"
    exit 1
fi

echo "Descărcare fișier: ${CHECKMK_FILE}..."
wget -P /tmp "${CHECKMK_URL}${CHECKMK_FILE}"

# Verifică dacă fișierul a fost descărcat și instalează
if [ -f "/tmp/${CHECKMK_FILE}" ]; then
    dpkg -i "/tmp/${CHECKMK_FILE}"
    # Instalează dependențele lipsă, dacă există
    apt-get -f install -y
    # Curățare fișier descărcat
    rm -f "/tmp/${CHECKMK_FILE}"
    echo "Agent CheckMK (${CHECKMK_FILE}) instalat cu succes."
else
    echo "Eroare: Nu s-a putut descărca agentul CheckMK (${CHECKMK_FILE})."
    exit 1
fi

# Verificare stare socket CheckMK
echo "Verificare stare check-mk-agent.socket..."
systemctl status check-mk-agent.socket --no-pager

# 7. Monitorizarea Sistemului cu Auditd
echo "Instalare și configurare auditd..."
apt update && apt install auditd audispd-plugins -y
systemctl enable --now auditd

# Configurare reguli de audit, inclusiv evidența utilizatorilor și activitățile pe kernel
echo "Configurare reguli audit pentru utilizatori și kernel..."
mkdir -p /etc/audit/rules.d
cat <<EOF > /etc/audit/rules.d/custom.rules
# Monitorizare modificări fișier /etc/passwd
-w /etc/passwd -p wa -k passwd_changes

# Monitorizare comenzi executate de root
-a always,exit -F arch=b64 -F euid=0 -S execve -k root_commands

# Monitorizare acces fișier /etc/shadow
-w /etc/shadow -p rwa -k shadow_access

# Monitorizare ștergeri sau redenumiri de fișiere
-a always,exit -F arch=b64 -S unlink,unlinkat,rename,renameat -k file_delete

# Monitorizare activități utilizatori pe kernel
# Executarea oricărei comenzi de către orice utilizator
-a always,exit -F arch=b64 -S execve -k user_commands

# Deschideri de fișiere de către utilizatori
-a always,exit -F arch=b64 -S open,openat -k user_file_access

# Creare sau modificare utilizatori/grupuri
-w /usr/sbin/useradd -p x -k user_management
-w /usr/sbin/usermod -p x -k user_management
-w /usr/sbin/groupadd -p x -k user_management
-w /usr/sbin/groupmod -p x -k user_management

# Excludere evenimente nesemnificative
-a never,task
EOF

# Aplicare reguli și repornire auditd
auditctl -R /etc/audit/rules.d/custom.rules
systemctl restart auditd

echo "Verificare stare auditd..."
systemctl status auditd --no-pager

echo "Hardening completat cu succes!"
echo "Verifică logurile și configurațiile manuale dacă este necesar."
echo "Pentru a verifica activitățile utilizatorilor, folosește: ausearch -k user_commands, ausearch -k user_file_access, etc."

exit 0
