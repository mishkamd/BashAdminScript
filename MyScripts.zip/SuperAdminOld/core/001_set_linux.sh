#!/bin/bash

# Verifică dacă utilizatorul este root
if [ "$EUID" -ne 0 ]; then
    echo "Acest script trebuie rulat ca root (sudo)"
    exit 1
fi

# Data curentă pentru backup
data=$(date +%Y-%m-%d_%H-%M-%S)
backup_dir="/var/backups/set-linux"

# Creează directorul de backup dacă nu există
mkdir -p "$backup_dir"

# Funcție pentru backup fișier
backup_file() {
    local file=$1
    if [ -f "$file" ]; then
        cp "$file" "$backup_dir/$(basename "$file").$data"
        echo "Backup creat pentru $file în $backup_dir/$(basename "$file").$data"
    else
        echo "Fișierul $file nu există, nu se face backup"
    fi
}

# Detectează prima interfață de rețea (excluzând lo)
interface=$(ip link | grep -v "lo:" | grep -oP '(?<=^\d: ).*?(?=:)' | head -n1)
if [ -z "$interface" ]; then
    echo "Nu s-a găsit nicio interfață de rețea activă!"
    exit 1
fi
echo "Interfața de rețea detectată: $interface"

# Cere hostname nou
echo "Introdu noul hostname (ex. server1):"
read new_hostname

# Cere adresa IP cu masca inclusă
echo "Introdu adresa IP cu masca CIDR (ex. 10.118.99.200/24):"
read ip_cidr

# Cere gateway
echo "Introdu adresa gateway (ex. 10.118.99.254):"
read gateway

# 1. Backup fișiere existente
echo "Fac backup la fișierele de configurare..."
backup_file "/etc/hostname"
backup_file "/etc/hosts"
backup_file "/etc/network/interfaces"
backup_file "/etc/resolv.conf"

# 2. Setează hostname-ul
echo "Setez hostname-ul la $new_hostname..."
hostnamectl set-hostname "$new_hostname"
echo "$new_hostname" > /etc/hostname

# 3. Actualizează /etc/hosts
echo "Actualizez /etc/hosts..."
cat > /etc/hosts << EOL
127.0.0.1       localhost
${ip_cidr%%/*}  energbank.com $new_hostname.energbank.com $new_hostname

# The following lines are desirable for IPv6 capable hosts
::1             localhost ip6-localhost ip6-loopback
ff02::1         ip6-allnodes
ff02::2         ip6-allrouters
EOL

# 4. Configurează interfața de rețea
echo "Configurez interfața de rețea $interface..."
cat > /etc/network/interfaces << EOL
# Interfața loopback
auto lo
iface lo inet loopback

# Interfața principală de rețea
allow-hotplug $interface
iface $interface inet static
    address $ip_cidr
    gateway $gateway
EOL

# 5. Actualizează /etc/resolv.conf
echo "Actualizez /etc/resolv.conf..."
cat > /etc/resolv.conf << EOL
domain energbank.com
search energbank.com
nameserver 10.118.10.211
nameserver 10.118.10.212
EOL

# 6. Aplică modificările
echo "Aplic modificările..."
systemctl restart networking.service

echo "Configurarea a fost completată!"
echo "Interfața: $interface"
echo "Hostname: $new_hostname"
echo "IP/CIDR: $ip_cidr"
echo "Gateway: $gateway"
echo "DNS 1: 10.118.10.211"
echo "DNS 2: 10.118.10.212"
echo "Backup-urile sunt salvate în $backup_dir"
echo "Este recomandat să repornești sistemul pentru a te asigura că toate modificările sunt aplicate corect."
