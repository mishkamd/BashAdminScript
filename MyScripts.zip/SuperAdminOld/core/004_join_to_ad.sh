#!/bin/bash
#Instaleaza packetele necesare pentru ad
apt -y remove --purge samba* libnss-winbind libpam-winbind
apt -y install samba libnss-winbind libpam-winbind

cp ../SuperAdmin/conf/smb.conf  /etc/samba/
cp ../SuperAdmin/conf/nsswitch.conf /etc/

chown 0:0 /etc/samba/smb.conf
chown 0:0 /etc/nsswitch.conf

# Adauga serverul in domain
domain=ENERGBANK
echo "-------------------------------"
echo "Introduceti credintealele:"
read -p "User: " user
net join -U "$domain\\$user"

#echo 'password'|net join -U energbank\\tivirencoadm

# Restart servicii
systemctl restart winbind
systemctl restart smbd
systemctl restart nmbd

#wbinfo -p
#sleep 2s
#wbinfo -P
#sleep 2s
#wbinfo -u
#sleep 2s
#wbinfo -g
#sleep 2s
#getent passwd
#sleep 2s
#getent group
#sleep 2s
