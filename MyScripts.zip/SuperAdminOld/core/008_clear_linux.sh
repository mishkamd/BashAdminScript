#!/bin/bash

# Verifică dacă scriptul rulează cu drepturi de root
if [ "$EUID" -ne 0 ]; then
    echo "Te rog rulează scriptul ca root (sudo)"
    exit 1
fi

# Afișează spațiul disc înainte de curățare
echo "Spațiu disc înainte de curățare:"
df -h /

echo "Începerea procesului de curățare a sistemului Debian 12..."

# 1. Curăță cache-ul APT
echo "Curăț cache-ul APT..."
apt-get clean
apt-get autoclean
apt-get autoremove -y

# 2. Șterge fișierele temporare
echo "Șterg fișierele temporare..."
rm -rf /tmp/*
rm -rf /var/tmp/*

# 3. Curăță cache-ul jurnalelor (logs)
echo "Curăț jurnalele vechi..."
journalctl --vacuum-time=2weeks

# 4. Șterge cache-ul utilizatorilor (opțional - decomentează dacă dorești)
echo "Curăț cache-ul utilizatorilor..."
find /home/*/.cache/ -type f -atime +30 -delete

# 5. Afișează spațiul liber după curățare
echo "Actualizez informațiile despre pachete..."
apt-get update
echo "Spațiu disc după curățare:"
df -h /

echo "Curățarea s-a finalizat cu succes!"
