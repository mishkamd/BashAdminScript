#!/bin/bash
## Datele pe care vor fi adaugate in fisier /etc/profile.d/proxy.sh
proxy_profile="export https_proxy=http://squid.energbank.com:3128/
export http_proxy=http://squid.energbank.com:3128/
export ftp_proxy=ftp://squid.energbank.com:3128/"
## Datele pe care vor fi adaugate in fisier /etc/apt/apt.conf.d/10proxy
touch /etc/apt/apt.conf.d/10proxy
proxy_apt="Acquire::http::Proxy \"http://squid.energbank.com:3128/\";
Acquire::https::Proxy \"http://squid.energbank.com:3128/\";"
## Datele pe care vor fi adaugate in fisier /etc/environment
proxy_environment="https_proxy = http://squid.energbank.com:3128/
http_proxy = http://squid.energbank.com:3128/
ftp_proxy = ftp://squid.energbank.com:3128/"

echo "Bine ati venit in proxy management!"
echo "Va rugam sa alegeti o optiune:"
echo "1. Activeaza Proxy"
echo "2. Dezactiveaza proxy"
echo "3. Proxy-ul personal"
read -p "Introduceti numarul optiunii: " choice

case $choice in
    1)
        # Activeaza proxy
        echo "$proxy_profile" > /etc/profile.d/proxy.sh
        echo "$proxy_apt" > /etc/apt/apt.conf.d/10proxy
        echo "$proxy_environment" > /etc/environment
        echo "Proxy-ul a fost activat cu succes"

				echo "PROFILE:"
				cat /etc/profile.d/proxy.sh
				echo "APT:"
				cat /etc/apt/apt.conf.d/10proxy
				echo "ENVIROMENT:"
				cat /etc/environment
		    ;;
    2)
        # Dezactiveaza proxy
        > /etc/profile.d/proxy.sh
        > /etc/apt/apt.conf.d/10proxy
        > /etc/environment
        echo "Proxy-ul a fost dezactivat"
				echo "PROFILE:"
				cat /etc/profile.d/proxy.sh
				echo "APT:"
				cat /etc/apt/apt.conf.d/10proxy
				echo "ENVIROMENT:"
				cat /etc/environment
        ;;
    3)
        #Proxy-custum
custum_proxy_profile="export https_proxy=http://$proxy_address:$proxy_port/
export http_proxy=http://$proxy_address:$proxy_port/
export ftp_proxy=ftp://$proxy_address:$proxy_port/"
touch /etc/apt/apt.conf.d/10proxy
custum_proxy_apt="Acquire::http::Proxy \"http://$proxy_address:$proxy_port/\";
Acquire::https::Proxy \"http://$proxy_address:$proxy_port/\";"
custum_proxy_environment="https_proxy = http://$proxy_address:$proxy_port/
http_proxy = http://$proxy_address:$proxy_port/
ftp_proxy = ftp://$proxy_address:$proxy_port/"

        # Activare proxy
        read -p "Introduceti adresa: " proxy_address
        read -p "Introduceti portul: " proxy_port

        echo "$custum_proxy_profile" > /etc/profile.d/proxy.sh
        echo "$custum_proxy_apt" > /etc/apt/apt.conf.d/10proxy
        echo "$custum_proxy_environment" > /etc/environment
        echo "Proxy-ul personal a fost activat cu succes"

				echo "PROFILE:"
				cat /etc/profile.d/proxy.sh
				echo "APT:"
				cat /etc/apt/apt.conf.d/10proxy
				echo "ENVIROMENT:"
				cat /etc/environment
        ;;
        *)
        echo "Optiune invalida."
        ;;
esac
