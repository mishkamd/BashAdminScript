#!/bin/bash

# Verifică dacă utilizatorul are privilegii de administrator
if [ "$EUID" -ne 0 ]; then
    echo "Scriptul trebuie rulat cu privilegii de administrator (sudo)."
    exit 1
fi

# Setează fusul orar la Europe/Chisinau
echo "Setez fusul orar la Europe/Chisinau..."
timedatectl set-timezone Europe/Chisinau
if [ $? -eq 0 ]; then
    echo "Fusul orar a fost setat cu succes"
else
    echo "Eroare la setarea fusului orar"
    exit 1
fi

# Definește serverul NTP
NTP_SERVER="10.118.10.20"

# Oprește alte servicii NTP care ar putea interfera
echo "Oprește alte servicii NTP potențiale..."
systemctl stop chrony 2>/dev/null
systemctl disable chrony 2>/dev/null
systemctl stop ntp 2>/dev/null
systemctl disable ntp 2>/dev/null

# Instalează și configurează systemd-timesyncd
echo "Instalez și configurez systemd-timesyncd..."
apt-get update && apt-get install -y systemd-timesyncd

NTP_CONF="/etc/systemd/timesyncd.conf"
if [ -f "$NTP_CONF" ]; then
    cp $NTP_CONF $NTP_CONF.bak
    grep "NTP=$NTP_SERVER" $NTP_CONF >/dev/null 2>&1 || (
        sed -i "/^#NTP=/d" $NTP_CONF
        sed -i "/^NTP=/d" $NTP_CONF
        echo "NTP=$NTP_SERVER" >> $NTP_CONF
    )
else
    echo "[Time]" > $NTP_CONF
    echo "NTP=$NTP_SERVER" >> $NTP_CONF
fi

# Pornește și verifică serviciul
echo "Pornește serviciul systemd-timesyncd..."
systemctl enable systemd-timesyncd
systemctl restart systemd-timesyncd

# Așteaptă câteva secunde pentru sincronizare
sleep 5

# Verifică dacă rulează
if systemctl is-active systemd-timesyncd >/dev/null 2>&1; then
    echo "systemd-timesyncd rulează cu succes!"
else
    echo "systemd-timesyncd a eșuat, trec la chrony..."
    
    # Fallback la chrony
    if ! command -v chronyd &> /dev/null; then
        echo "Instalez chrony..."
        apt-get update && apt-get install -y chrony
    fi
    echo "server $NTP_SERVER iburst" > /etc/chrony/chrony.conf
    systemctl restart chrony
    chronyc -a 'burst 4/4' 2>/dev/null
fi

# Afișează informații
echo "#####################################"
echo "Informații despre sincronizare și oră:"
if systemctl is-active systemd-timesyncd >/dev/null 2>&1; then
    echo "        --Server NTP (systemd-timesyncd)--"
    timedatectl timesync-status
elif systemctl is-active chrony >/dev/null 2>&1; then
    echo "        --Server NTP (chrony)--"
    chronyc sources
else
    echo "Eroare: Niciun serviciu NTP nu rulează"
    exit 1
fi

echo 'en_US.UTF-8 UTF-8' >/etc/locale.gen
echo 'ru_RU.UTF-8 UTF-8' >>/etc/locale.gen
echo 'LANG=en_US.UTF-8' >/etc/default/locale
/usr/sbin/locale-gen

echo "        --Date Info--"
date
echo "        --Stare completă--"
timedatectl

echo "Configurarea a fost finalizată!"
