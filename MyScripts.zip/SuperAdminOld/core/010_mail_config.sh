#!/bin/bash

##Sterge si instaleaza exim4
apt-get -y remove --purge exim4
apt-get -y install exim4


cp ../SuperAdmin/conf/aliases /etc/
chown 0:0 /etc/aliases

FQDN=`hostname -f`
HOST=`hostname -s`

echo $FQDN >/etc/mailname
#FILE=/etc/hosts
#sed -r -i "{s/127.0.1.1\s*(.*?)\s*(.*?)/127.0.1.1 $FQDN $HOST/}" $FILE

#sed -r -i "{s/oldtext/newtext/g}" $FILE
#sed -r -i "{s/text=\"(.*?)\"/text=\"$NEW_VALUE\"/}" $FILE

FILE=/etc/exim4/update-exim4.conf.conf
# dc_eximconfig_configtype='satellite'
sed -r -i "{s/dc_eximconfig_configtype='(.*?)'/dc_eximconfig_configtype='satellite'/}" $FILE

# dc_other_hostnames='HOSTNAME.energbank.com'
sed -r -i "{s/dc_other_hostnames='(.*?)'/dc_other_hostnames='$FQDN'/}" $FILE

# dc_readhost='HOSTNAME.energbank.com'
sed -r -i "{s/dc_readhost='(.*?)'/dc_readhost='$FQDN'/}" $FILE

# dc_smarthost='mailserver.energbank.com'
sed -r -i "{s/dc_smarthost='(.*?)'/dc_smarthost='mailserver.energbank.com'/}" $FILE

# test mail
echo `date` `hostname` $0|mail root
