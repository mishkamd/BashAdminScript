#openssl req -new -newkey rsa:2048 -nodes -out www.energbank.com.csr -keyout www.energbank.com.key -subj "/C=MD/ST=Moldova/L=Chisinau/O=BC ENENERGBANK SA/OU=DTI/CN=www.energbank.com"
openssl req -new -newkey rsa:2048 -nodes -out api.energbank.com.csr -keyout api.energbank.com.key -subj "/C=MD/ST=Moldova/L=Chisinau/O=BC ENENERGBANK SA/OU=DTI/CN=api.energbank.com"

