#!/bin/bash
key_modulus=$(openssl rsa -in api.energbank.com.key -modulus -noout | cut -d'=' -f2)
crt_modulus=$(openssl x509 -in api.energbank.com.crt -modulus -noout | cut -d'=' -f2)

if [ "$key_modulus" = "$crt_modulus" ]; then
    echo "Cheia privată și certificatul sunt o pereche validă!"
else
    echo "Cheia privată și certificatul NU sunt compatibile."
fi
