#!/bin/bash
# Date și sursă
date=$(date +%Y.%m.%d)
date_time=$(date +"%d.%m.%Y - %H:%M:%S")
source_dir="/home/sftp/beforeSend2MMC/$date"
send_dir="/home/sftp/mmc_user/root/CMS/E_FILE_MMC/"
log_file="/etc/ENB/mmc-encrypt.log"  # Calea către fișierul de jurnal

# Verifică dacă directorul destinație există
if [ ! -d "/media/ecard/OUT_FILE" ]; then
  echo "$date_time | Directorul /media/ecard/OUT_FILE nu este montat." | tee -a "$log_file"
  exit 1
fi

# Creează director nou cu data de astăzi
mkdir -p "$source_dir"

# Copiază toate fișierele în directorul sursă
mv /media/ecard/OUT_FILE/* "$source_dir"

# Verifică dacă directorul sursă există
if [ ! -d "$source_dir" ]; then
  echo "$date_time | Directorul sursă $source_dir nu există." | tee -a "$log_file"
  exit 1
fi

# Verifică dacă directorul destinație există
if [ ! -d "$send_dir" ]; then
  echo "$date_time | Directorul destinație $send_dir nu există." | tee -a "$log_file"
  exit 1
fi

# Criptează toate fișierele în .gpg
for file in "$source_dir"/*; do
  if [ -f "$file" ]; then
    # Extrage extensia fișierului
    extension="${file##*.}"
    # Verifică dacă extensia este ".eM" sau ".eV"
    if [ "$extension" = "eM" ] || [ "$extension" = "eV" ]; then
      gpg --trust-model always --recipient cmsdb@mmc.md  --yes --encrypt "$file" | tee -a "$log_file"
    fi
  fi
done

# Copiază fișierele .gpg
cp "$source_dir"/*.gpg "$send_dir"

# Anunță despre copiere în MMC
if [ -z "$(ls -A "$send_dir")" ]; then
  echo "$date_time | Nu există fișiere în directorul $send_dir." | tee -a "$log_file"
else
  echo "$date_time | Fișierele GPG sunt copiate cu succes în directorul $send_dir" | tee -a "$log_file"
  echo "$date_time | ls -lh "$send_dir"" | tee -a "$log_file"
fi
ls -lh "$send_dir" | tee -a "$log_file"

