#!/bin/bash

DOMAIN=miapos-t.energbank.com
DOMAIN1=mia-t.energbank.com


openssl pkcs12 -in $DOMAIN.p12 -nocerts -nodes -out $DOMAIN.key
openssl pkcs12 -in $DOMAIN.p12 -nokeys -out $DOMAIN.crt
openssl pkcs12 -in $DOMAIN1.p12 -nocerts -nodes -out $DOMAIN1.key
openssl pkcs12 -in $DOMAIN1.p12 -nokeys -out $DOMAIN1.crt
