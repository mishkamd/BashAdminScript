#!/bin/bash

DOMAIN=miapos.energbank.com

openssl pkcs12 -in $DOMAIN.p12 -nocerts -nodes -out $DOMAIN.key
openssl pkcs12 -in $DOMAIN.p12 -nokeys -out $DOMAIN.crt
