#!/bin/bash
SOURCE_DIR="/mnt/hq/dump"
DEST_DIR="/mnt/dr/dump-netappHQ"
LOG_FILE="/etc/ENB/migrate/logs/cleanup.log"

# Funcție pentru curățare (fișier log, etc.)
cleanup() {
  echo "Curățare resurse..." | tee -a "$LOG_FILE"
}

# Atașează funcția cleanup la semnalele de terminare (EXIT, INT, TERM)
trap cleanup EXIT INT TERM

# Asigură existența directorului logului
mkdir -p "$(dirname "$LOG_FILE")"

# Verifică dacă directoarele există
if [ ! -d "$SOURCE_DIR" ]; then
  echo "Eroare: Directorul sursă $SOURCE_DIR nu există!" | tee -a "$LOG_FILE"
  exit 1
fi

if [ ! -d "$DEST_DIR" ]; then
  echo "Eroare: Directorul destinație $DEST_DIR nu există!" | tee -a "$LOG_FILE"
  exit 1
fi

echo "=== $(date) ===" | tee -a "$LOG_FILE"
echo "Începerea curățării fișierelor vechi din directorul destinație..." | tee -a "$LOG_FILE"

# Compară directoarele și șterge fișierele care nu există în sursă
rsync -av --progress --ignore-existing --delete \
  --include="*/" \
  --include="*.log" \
  --include="*.vma.zst" \
  --include="*.vma.zst.notes" \
  --exclude="*" \
  "$SOURCE_DIR/" "$DEST_DIR/" | tee -a "$LOG_FILE"

echo "Procesul de curățare s-a încheiat." | tee -a "$LOG_FILE"
