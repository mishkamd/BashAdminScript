echo "#-- HQ-BACKUP --#"
du -h /mnt/hq/dump/
echo "#-- DR-BACKUP --#"
du -h /mnt/dr/dump-netappHQ
